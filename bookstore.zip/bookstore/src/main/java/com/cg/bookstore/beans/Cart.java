package com.cg.bookstore.beans;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;



@Entity
@Table(name = "cart")
public class Cart {
	
	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="cart_ID")
	private int cartId;
	
	@OneToMany(cascade= CascadeType.ALL)
	private List<CartDetails> cartDetails = new ArrayList<CartDetails>();
	@Column(name="total")
	private Double total;
	public Cart(int cartId, List<CartDetails> cartDetails, Double total) {
		super();
		this.cartId = cartId;
		this.cartDetails = cartDetails;
		this.total = total;
	}
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public List<CartDetails> getCartDetails() {
		return cartDetails;
	}
	public void setCartDetails(List<CartDetails> cartDetails) {
		this.cartDetails = cartDetails;
	}
	public Double getTotal() {
		return total;
	}
	public void setTotal(Double total) {
		this.total = total;
	}
	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", cartDetails=" + cartDetails + ", total=" + total + "]";
	}
	
}
