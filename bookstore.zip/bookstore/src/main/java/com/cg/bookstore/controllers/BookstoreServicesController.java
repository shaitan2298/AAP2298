package com.cg.bookstore.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bookstore.beans.Books;
import com.cg.bookstore.beans.Category;
import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.exceptions.BookNotFoundException;
import com.cg.bookstore.exceptions.CategoryNotFoundException;
import com.cg.bookstore.exceptions.CustomerNotFoundException;
import com.cg.bookstore.services.BookstoreServicesImpl;

@Controller
public class BookstoreServicesController 
{
  @Autowired
  public BookstoreServicesImpl bookstoreService;
  
  @RequestMapping(value="/acceptCustomerDetails", method=RequestMethod.POST)
  public ResponseEntity<String> getAcceptCustomerDetails(@ModelAttribute Customer customer)
  {
  	customer = bookstoreService.acceptCustomerDetails(customer);
  	return new ResponseEntity<String>("Customer Details Accepted Successfully!\n" + customer,HttpStatus.OK);
  }
  
  @RequestMapping(value= {"/getCustomerDetails/{customerId}"},method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE,
  		headers="Accept=application/json")
  public ResponseEntity<Customer> getCustomerDetailsPathParam(@PathVariable(value="customerId") Integer customerId)throws CustomerNotFoundException
  {
	  Customer customer = bookstoreService.getCustomerDetails(customerId);
  	return new ResponseEntity<Customer>(customer,HttpStatus.OK);
  }
  @RequestMapping(value= {"/getAllCustomerDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
  		headers="Accept=application/json")
  public ResponseEntity<List<Customer>> getAllCustomerDetailsPathParam()
  {
  	return new ResponseEntity<List<Customer>>(bookstoreService.getAllCustomerDetails(),HttpStatus.OK);
  }
  
  @RequestMapping(value= {"/deleteCustomer/{customerId}"},method=RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE,
	  		headers="Accept=application/json")
	  public ResponseEntity<String> deleteCustomerPathParam(@PathVariable(value="customerId") Integer customerId)throws CustomerNotFoundException
	  {
		  Customer customer = bookstoreService.removeCustomer(customerId);
	  	  return new ResponseEntity<String>("Customer Details Removed Successfully!\ncustomerID=" +customerId,HttpStatus.OK);
	  }

  @RequestMapping(value={"/updateCustomerDetails"},method=RequestMethod.PUT,produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json") 
  public ResponseEntity<Boolean>updateCustomerDetails(@RequestParam Integer customerId,@ModelAttribute Customer customer)throws CustomerNotFoundException 
	  {
      boolean updateStatus = bookstoreService.updateCustomerDetails(customerId, customer);
      System.out.println("update..."+customer);
  return new ResponseEntity<Boolean>(updateStatus,HttpStatus.OK); }
  
  
  
  @RequestMapping(value="/acceptCategoryDetails", method=RequestMethod.POST)
  public ResponseEntity<String> getAcceptCategoryDetails(@ModelAttribute Category category)
  {
	category = bookstoreService.acceptCategoryDetails(category);
  	return new ResponseEntity<String>("Category Details Accepted Successfully!\n" + category,HttpStatus.OK);
  }
  
  @RequestMapping(value= {"/getCategoryDetails/{categoryName}"},method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE,
  		headers="Accept=application/json")
  public ResponseEntity<Category> getCategoryDetailsPathParam(@PathVariable(value="categoryName") String categoryName)throws CategoryNotFoundException
  {
	  Category category = bookstoreService.getCategoryDetails(categoryName);
  	return new ResponseEntity<Category>(category,HttpStatus.OK);
  }
  @RequestMapping(value= {"/getAllCategoryDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
  		headers="Accept=application/json")
  public ResponseEntity<List<Category>> getAllCategoryDetailsPathParam()
  {
  	return new ResponseEntity<List<Category>>(bookstoreService.getAllCategoryDetails(),HttpStatus.OK);
  }
  
  @RequestMapping(value= {"/deleteCategory/{categoryName}"},method=RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE,
	  		headers="Accept=application/json")
	  public ResponseEntity<String> deleteCategoryPathParam(@PathVariable(value="categoryName") String categoryName)throws CategoryNotFoundException
	  {
		  Category category = bookstoreService.removeCategory(categoryName);
	  	  return new ResponseEntity<String>("Category Details Removed Successfully!\ncustomerID=" +categoryName,HttpStatus.OK);
	  }

  @RequestMapping(value={"/updateCategoryDetails"},method=RequestMethod.PUT,produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json") 
  public ResponseEntity<Boolean>updateCategoryDetails(@RequestParam String categoryName,@ModelAttribute Category category)throws CategoryNotFoundException 
	  {
      boolean updateStatus = bookstoreService.updateCategoryDetails(categoryName, category);
      System.out.println("update..."+category);
  return new ResponseEntity<Boolean>(updateStatus,HttpStatus.OK); }
  
  
  
  @RequestMapping(value="/acceptBookDetails", method=RequestMethod.POST)
  public ResponseEntity<String> getAcceptBookDetails(@ModelAttribute Books book)
  {
	book = bookstoreService.acceptBookDetails(book);
  	return new ResponseEntity<String>("Book Details Accepted Successfully!\n" + book,HttpStatus.OK);
  }
  
  @RequestMapping(value= {"/getBookDetails/{bookId}"},method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE,
  		headers="Accept=application/json")
  public ResponseEntity<Books> getBookDetailsPathParam(@PathVariable(value="bookId") Integer bookId)throws BookNotFoundException
  {
	  Books book = bookstoreService.getBookDetails(bookId);
  	return new ResponseEntity<Books>(book,HttpStatus.OK);
  }
  @RequestMapping(value= {"/getAllBookDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
  		headers="Accept=application/json")
  public ResponseEntity<List<Books>> getAllBookDetailsPathParam()
  {
  	return new ResponseEntity<List<Books>>(bookstoreService.getAllBookDetails(),HttpStatus.OK);
  }
  
  @RequestMapping(value= {"/deleteBook/{bookId}"},method=RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE,
	  		headers="Accept=application/json")
	  public ResponseEntity<String> deleteBookPathParam(@PathVariable(value="bookId") Integer bookId)throws BookNotFoundException
	  {
		  Books book = bookstoreService.removeBook(bookId);
	  	  return new ResponseEntity<String>("Book Details Removed Successfully!\ncustomerID=" +bookId,HttpStatus.OK);
	  }

  @RequestMapping(value={"/updateBookDetails"},method=RequestMethod.PUT,produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json") 
  public ResponseEntity<Boolean>updateBookDetails(@RequestParam Integer bookId,@ModelAttribute Books book)throws BookNotFoundException 
	  {
      boolean updateStatus = bookstoreService.updateBookDetails(bookId, book);
      System.out.println("update..."+book);
  return new ResponseEntity<Boolean>(updateStatus,HttpStatus.OK); }
  
}
