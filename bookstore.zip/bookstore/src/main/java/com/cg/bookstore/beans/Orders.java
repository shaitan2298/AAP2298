package com.cg.bookstore.beans;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "orders")
public class Orders {
	
	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ord_Id",length=10)
	private int orderId;
	@NotNull
	@Column(name="total")
	private Double total;
	@NotNull
	@Column(name="status")
	private String orderStatus;
	@Column(name="payment_method")
	private String paymentMethod;
	@ManyToOne
	@JoinColumn(name="cust_Id")
	private Customer customer; 
	@OneToMany(cascade= CascadeType.ALL)
	private List<OrderDetails> ordersDeails =  new ArrayList<OrderDetails>();
	public Orders(int orderId, Double total, String orderStatus, String paymentMethod, Customer custmerId,
			List<OrderDetails> ordersDeails) {
		super();
		this.orderId = orderId;
		this.total = total;
		this.orderStatus = orderStatus;
		this.paymentMethod = paymentMethod;
		this.customer = customer;
		this.ordersDeails = ordersDeails;
	}
	public Orders() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Double getTotal() {
		return total;
	}
	public void setTotal(Double total) {
		this.total = total;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public List<OrderDetails> getOrdersDeails() {
		return ordersDeails;
	}
	public void setOrdersDeails(List<OrderDetails> ordersDeails) {
		this.ordersDeails = ordersDeails;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", total=" + total + ", orderStatus=" + orderStatus + ", paymentMethod="
				+ paymentMethod + ", customer=" + customer + ", ordersDeails=" + ordersDeails + "]";
	}
	

}
