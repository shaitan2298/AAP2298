package com.cg.bookstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.bookstore.beans.Books;
import com.cg.bookstore.beans.Category;
import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.dao.BooksDAO;
import com.cg.bookstore.dao.CategoryDAO;
import com.cg.bookstore.dao.CustomerDAO;
import com.cg.bookstore.dao.OrdersDAO;
import com.cg.bookstore.exceptions.BookNotFoundException;
import com.cg.bookstore.exceptions.CategoryNotFoundException;
import com.cg.bookstore.exceptions.CustomerNotFoundException;

@Component
public class BookstoreServicesImpl implements IBookstoreServices
{
	public static String adminPassword = "AAP@2298";
	@Autowired
	private CustomerDAO customerDAO;
	@Autowired
	private CategoryDAO categoryDAO;
	@Autowired
	private BooksDAO booksDAO;
	@Autowired
	private OrdersDAO ordersDAO;

	@Override
	public Customer acceptCustomerDetails(Customer customer) {
		customer = customerDAO.save(customer);
		return customer;
	}

	@Override
	public Customer getCustomerDetails(Integer customerId) throws CustomerNotFoundException {
		Customer customer = customerDAO.findById(customerId).orElseThrow(()-> new CustomerNotFoundException("Customer Not Found!"));
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		
		return customerDAO.findAll();
	}

	@Override
	public Customer removeCustomer(Integer customerId) throws CustomerNotFoundException {
		Customer customer = customerDAO.findById(customerId).orElseThrow(()-> new CustomerNotFoundException("Customer Not Found!"));
		customerDAO.deleteById(customerId);
		return customer;
	}

	@Override
	public boolean updateCustomerDetails(Integer customerId, Customer customer) throws CustomerNotFoundException {
		getCustomerDetails(customerId);
		acceptCustomerDetails(customer);
		customer.setCustomerId(customerId);
		customerDAO.save(customer);
		return true;
	}

	@Override
	public Category acceptCategoryDetails(Category category) {
		category = categoryDAO.save(category);
		
		return category;
	}

	@Override
	public Category getCategoryDetails(String categoryName) throws CategoryNotFoundException {
		Category category = categoryDAO.findById(categoryName).orElseThrow(()-> new CategoryNotFoundException("Category Not Found!"));
		return category;
	}

	@Override
	public List<Category> getAllCategoryDetails() {
		
		return categoryDAO.findAll();
	}

	@Override
	public Category removeCategory(String categoryName) throws CategoryNotFoundException {
		Category category = categoryDAO.findById(categoryName).orElseThrow(()-> new CategoryNotFoundException("Category Not Found!"));
		categoryDAO.deleteById(categoryName);
		return category;
	}

	@Override
	public boolean updateCategoryDetails(String categoryName, Category category) throws CategoryNotFoundException {
		getCategoryDetails(categoryName);
		acceptCategoryDetails(category);
		category.setCategoryName(categoryName);
		categoryDAO.save(category);
		return true;
	}

	@Override
	public Books acceptBookDetails(Books books) {
		books = booksDAO.save(books);
		return books;
	}

	@Override
	public Books getBookDetails(Integer bookId) throws BookNotFoundException {
		Books book = booksDAO.findById(bookId).orElseThrow(()-> new BookNotFoundException("Book Not Found!"));
		return book;
	}

	@Override
	public List<Books> getAllBookDetails() {
		
		return booksDAO.findAll();
	}

	@Override
	public Books removeBook(Integer bookId) throws BookNotFoundException {
        Books books = getBookDetails(bookId);
        booksDAO.deleteById(bookId);
		return books;
	}

	@Override
	public boolean updateBookDetails(Integer bookId, Books books) throws BookNotFoundException {
		getBookDetails(bookId);
		acceptBookDetails(books);
		books.setBookId(bookId);
		booksDAO.save(books);
		return true;
	}
   
}
