package com.cg.bookstore.services;

import java.util.List;

import com.cg.bookstore.beans.Books;
import com.cg.bookstore.beans.Category;
import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.exceptions.BookNotFoundException;
import com.cg.bookstore.exceptions.CategoryNotFoundException;
import com.cg.bookstore.exceptions.CustomerNotFoundException;



public interface IBookstoreServices 
{	//customer
	public Customer acceptCustomerDetails(Customer customer);
	public Customer getCustomerDetails(Integer customerId) throws CustomerNotFoundException;	
	public List<Customer> getAllCustomerDetails();	
	public Customer removeCustomer(Integer customerId) throws CustomerNotFoundException;	
	public boolean updateCustomerDetails(Integer customerId,Customer customer)throws CustomerNotFoundException;
	//category
	public Category acceptCategoryDetails(Category category);	
	public Category getCategoryDetails(String categoryName) throws CategoryNotFoundException;
	public List<Category> getAllCategoryDetails();	
	public Category removeCategory(String categoryName) throws CategoryNotFoundException;	
	public boolean updateCategoryDetails(String categoryName,Category category)throws CategoryNotFoundException;
	//books
	public Books acceptBookDetails(Books books);	
	public Books getBookDetails(Integer bookId) throws BookNotFoundException;
	public List<Books> getAllBookDetails();	
	public Books removeBook(Integer bookId) throws BookNotFoundException;	
	public boolean updateBookDetails(Integer bookId,Books books)throws BookNotFoundException;
    
	

}

