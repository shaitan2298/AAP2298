package com.cg.bookstore.beans;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int customerId;
	private String customerFullName;
	private String customerEmail;
	private String password;
	private String customerPhoneNumber;
	private String customerAddress;
	private String customerZipCode;
	private String customerCity;
	private String country;
	@OneToMany(cascade= CascadeType.ALL)
	private List<Orders> orders =  new ArrayList<Orders>();
	@OneToMany(cascade= CascadeType.ALL)
	private List<BookReview>  bookreview = new ArrayList<BookReview>();
	@OneToOne
	private Cart cart;
	public Customer(int customerId, String customerFullName, String customerEmail, String password,
			String customerPhoneNumber, String customerAddress, String customerZipCode, String customerCity,
			String country, List<Orders> orders, List<BookReview> bookreview, Cart cart) {
		super();
		this.customerId = customerId;
		this.customerFullName = customerFullName;
		this.customerEmail = customerEmail;
		this.password = password;
		this.customerPhoneNumber = customerPhoneNumber;
		this.customerAddress = customerAddress;
		this.customerZipCode = customerZipCode;
		this.customerCity = customerCity;
		this.country = country;
		this.orders = orders;
		this.bookreview = bookreview;
		this.cart = cart;
	}
	public Customer() {
		super();
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerFullName() {
		return customerFullName;
	}
	public void setCustomerFullName(String customerFullName) {
		this.customerFullName = customerFullName;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCustomerPhoneNumber() {
		return customerPhoneNumber;
	}
	public void setCustomerPhoneNumber(String customerPhoneNumber) {
		this.customerPhoneNumber = customerPhoneNumber;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getCustomerZipCode() {
		return customerZipCode;
	}
	public void setCustomerZipCode(String customerZipCode) {
		this.customerZipCode = customerZipCode;
	}
	public String getCustomerCity() {
		return customerCity;
	}
	public void setCustomerCity(String customerCity) {
		this.customerCity = customerCity;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public List<Orders> getOrders() {
		return orders;
	}
	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}
	public List<BookReview> getBookreview() {
		return bookreview;
	}
	public void setBookreview(List<BookReview> bookreview) {
		this.bookreview = bookreview;
	}
	public Cart getCart() {
		return cart;
	}
	public void setCart(Cart cart) {
		this.cart = cart;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerFullName=" + customerFullName + ", customerEmail="
				+ customerEmail + ", password=" + password + ", customerPhoneNumber=" + customerPhoneNumber
				+ ", customerAddress=" + customerAddress + ", customerZipCode=" + customerZipCode + ", customerCity="
				+ customerCity + ", country=" + country + ", orders=" + orders + ", bookreview=" + bookreview
				+ ", cart=" + cart + "]";
	}
	

	
	
}